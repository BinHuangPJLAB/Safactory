import requests
from typing import Type, TypeVar, Callable, Any
from functools import wraps

T = TypeVar("RspData")  

class SDKException(Exception):
    def __init__(self, code: int,  message: str = "", status: str = "Error", reason: str = ""):
        self.status = status
        self.code = code
        self.reason = reason
        self.message = message
        super().__init__(f"[{code} {reason}] {message}")
        

def extract_data(model: type[T]) -> Callable[[Callable[..., requests.Response]], Callable[..., T]]:
    """
    装饰器：将接口返回的 JSON.Data 转换为模型对象。
    支持 HTTP 错误和自定义 API 错误结构：
    {
        "Status": "Failure",
        "Code": 403,
        "Reason": "Forbidden",
        "Message": "user not allowed"
    }
    成功时：
    {
        "Data": {...},
        "Status": "Success",
        "Code": 200
    }
    """
    def decorator(func: Callable[..., requests.Response]) -> Callable[..., T]:
        @wraps(func)
        def wrapper(*args, **kwargs) -> T:
            response = func(*args, **kwargs)
            rsp_json = None
            try:
                if response and response.text:
                    rsp_json = response.json()
            except ValueError:
                raise  # 返回均为json
           
            
            if not response.ok:
                if rsp_json is not None:
                    raise SDKException(
                        status=rsp_json.get("status", "HTTP Error"),
                        code=rsp_json.get("code", response.status_code),
                        reason=rsp_json.get("reason", response.reason),
                        message=rsp_json.get("message", response.text),
                    )
                else:
                    raise SDKException(
                        status="HTTP Error",
                        code=response.status_code,
                        reason=response.reason,
                        message=response.text,
                    )
            else:
                data = rsp_json.get("data") if rsp_json else None
                if  data is None and  model == bool:
                    return True  
                if data and isinstance(data, dict):
                    return model.from_dict(data)
                else:
                    raise SDKException(
                        status="Error",
                        code=response.status_code,
                        reason="InvalidData",
                        message="Response data is not valid",
                    )
        return wrapper
    return decorator
